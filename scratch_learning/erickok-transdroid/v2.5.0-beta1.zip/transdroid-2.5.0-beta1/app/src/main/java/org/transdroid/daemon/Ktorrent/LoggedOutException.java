package org.transdroid.daemon.Ktorrent;

public class LoggedOutException extends Exception {

	private static final long serialVersionUID = 1L;

}
