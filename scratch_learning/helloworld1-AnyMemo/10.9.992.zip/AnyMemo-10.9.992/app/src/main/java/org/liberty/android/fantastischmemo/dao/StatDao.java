package org.liberty.android.fantastischmemo.dao;

import com.j256.ormlite.dao.Dao;

import org.liberty.android.fantastischmemo.entity.Stat;

public interface StatDao extends Dao<Stat, Integer> {
}
