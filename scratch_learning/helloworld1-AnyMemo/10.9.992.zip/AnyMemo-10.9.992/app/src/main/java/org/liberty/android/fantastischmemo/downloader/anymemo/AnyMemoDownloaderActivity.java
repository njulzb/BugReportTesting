package org.liberty.android.fantastischmemo.downloader.anymemo;

import android.os.Bundle;

import org.liberty.android.fantastischmemo.R;
import org.liberty.android.fantastischmemo.common.BaseActivity;

public class AnyMemoDownloaderActivity extends BaseActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.anymemo_downloader);
    }
}
