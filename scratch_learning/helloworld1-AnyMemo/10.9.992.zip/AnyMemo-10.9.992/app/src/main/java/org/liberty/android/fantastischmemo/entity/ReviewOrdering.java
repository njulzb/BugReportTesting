package org.liberty.android.fantastischmemo.entity;

/**
 * The review ordering
 */
public enum ReviewOrdering {
    Random,
    HardestFirst;
}