package org.liberty.android.fantastischmemo.dao;

import com.j256.ormlite.dao.Dao;

import org.liberty.android.fantastischmemo.entity.Filter;

public interface FilterDao extends Dao<Filter, Integer> {
}
