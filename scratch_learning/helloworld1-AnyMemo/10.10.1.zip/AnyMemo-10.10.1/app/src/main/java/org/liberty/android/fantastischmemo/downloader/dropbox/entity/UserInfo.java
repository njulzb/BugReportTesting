package org.liberty.android.fantastischmemo.downloader.dropbox.entity;

public class UserInfo {
    public String displayName;
    public String accountId;
    public String email;
}
