package com.github.yeriomin.yalpstore;

public class SignatureMismatchException extends Exception {
}
