package com.github.yeriomin.yalpstore;

public class NotPurchasedException extends Exception {
}
