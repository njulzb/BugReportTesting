AUTHORS
=======

### Development
Transistor is designed, developed and maintained by: [y20k](https://github.com/y20k)

Contributing developer(s):
[meonwax](https://github.com/meonwax) 

### Translations
French version: [M2ck](https://github.com/M2ck)

German version: [y20k](https://github.com/y20k)

Japanese version: [naofum](https://github.com/naofum)

Russian version: [Boris Timofeev](https://github.com/btimofeev)

Serbian version: [pejakm](https://github.com/pejakm)

Slovenian version: [bungabunga](https://github.com/bungabunga)

Spanish version: [franciscot](https://github.com/franciscot)

Ukrainian version: [burunduk](https://github.com/burunduk) 

### Want to help?
Please check out the notes in [CONTRIBUTE.md](https://github.com/y20k/transistor/blob/master/CONTRIBUTE.md) first.
