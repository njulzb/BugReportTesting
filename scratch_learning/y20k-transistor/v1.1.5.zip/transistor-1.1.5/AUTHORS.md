AUTHORS
=======

### Development
Transistor is designed, developed and maintained by [Y20K.org](http://www.y20k.org/)

### Translations
French version:  [M2ck](https://github.com/M2ck)

Ukrainian version: [burunduk](https://github.com/burunduk) 