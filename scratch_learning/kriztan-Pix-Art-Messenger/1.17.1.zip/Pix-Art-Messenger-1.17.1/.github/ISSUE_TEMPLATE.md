#### General information

* **Version:** eg 1.12.2
* **Device:** eg Google Nexus 5
* **Android Version:** eg Android 6.0 Stock or Android 5.1 Cyanogenmod

#### Steps to reproduce

1. …
2. …


#### Expected result

What is the expected output? What do you see instead?


#### Debug output

Please post the output of adb logcat. The log should begin with the start of Pix-Art Messenger and include all the
steps it takes to reproduce the problem.

````
adb -d logcat -v time | FINDSTR Pix-Art > logcat.txt
````
