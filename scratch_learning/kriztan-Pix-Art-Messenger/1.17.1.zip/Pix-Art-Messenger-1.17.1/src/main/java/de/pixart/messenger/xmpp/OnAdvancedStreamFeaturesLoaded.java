package de.pixart.messenger.xmpp;

import de.pixart.messenger.entities.Account;

public interface OnAdvancedStreamFeaturesLoaded {
    public void onAdvancedStreamFeaturesAvailable(final Account account);
}
