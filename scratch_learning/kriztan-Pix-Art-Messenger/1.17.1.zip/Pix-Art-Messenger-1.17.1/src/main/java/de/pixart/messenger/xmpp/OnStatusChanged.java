package de.pixart.messenger.xmpp;

import de.pixart.messenger.entities.Account;

public interface OnStatusChanged {
    public void onStatusChanged(Account account);
}
