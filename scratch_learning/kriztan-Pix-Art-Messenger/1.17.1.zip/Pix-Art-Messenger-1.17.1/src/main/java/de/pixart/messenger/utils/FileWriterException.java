package de.pixart.messenger.utils;

public class FileWriterException extends Exception {
}
