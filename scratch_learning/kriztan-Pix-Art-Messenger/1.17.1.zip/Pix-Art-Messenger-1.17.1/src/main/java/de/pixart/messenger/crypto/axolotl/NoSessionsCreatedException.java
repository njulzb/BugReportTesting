package de.pixart.messenger.crypto.axolotl;

public class NoSessionsCreatedException extends Throwable {
}
