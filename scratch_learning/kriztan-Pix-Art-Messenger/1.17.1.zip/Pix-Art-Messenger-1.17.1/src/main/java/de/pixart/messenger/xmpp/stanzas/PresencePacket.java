package de.pixart.messenger.xmpp.stanzas;

public class PresencePacket extends AbstractAcknowledgeableStanza {

    public PresencePacket() {
        super("presence");
    }
}
