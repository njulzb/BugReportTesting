package de.pixart.messenger.ui;

import android.app.Activity;
import android.os.Bundle;

import de.pixart.messenger.R;

public class AboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
