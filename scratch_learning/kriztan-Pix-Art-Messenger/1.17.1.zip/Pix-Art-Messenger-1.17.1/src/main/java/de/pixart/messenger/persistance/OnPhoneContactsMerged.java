package de.pixart.messenger.persistance;

public interface OnPhoneContactsMerged {
    public void phoneContactsMerged();
}
