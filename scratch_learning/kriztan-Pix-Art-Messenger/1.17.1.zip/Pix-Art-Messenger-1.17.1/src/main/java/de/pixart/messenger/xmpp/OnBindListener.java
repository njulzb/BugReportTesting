package de.pixart.messenger.xmpp;

import de.pixart.messenger.entities.Account;

public interface OnBindListener {
    public void onBind(Account account);
}
