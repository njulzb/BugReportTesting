package de.pixart.messenger.xmpp;

public abstract interface PacketReceived {

}
