package com.commit451.gitlab.event;

/**
 * Close the drawer!
 * Created by Jawn on 7/28/2015.
 */
public class CloseDrawerEvent {
}
