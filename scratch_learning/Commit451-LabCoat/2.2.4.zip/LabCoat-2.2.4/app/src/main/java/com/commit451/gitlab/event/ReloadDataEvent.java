package com.commit451.gitlab.event;

/**
 * Signifies that the fragments should reload their data
 * Created by Jawn on 9/1/2015.
 */
public class ReloadDataEvent {
}
