package com.commit451.gitlab.event;

/**
 * Reload all the issues!
 */
public class IssueReloadEvent {
}
