package com.commit451.gitlab.event;

/**
 * Created by Jawn on 8/21/2015.
 */
public class LogoutEvent {
}
